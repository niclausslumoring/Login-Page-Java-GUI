import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class LoginDuluBos {

	public static void main(String[] args) {
		JPanel jp = new JPanel();
		JFrame jf = new JFrame();
		jf.setSize(350, 200);
		jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		jf.setVisible(true);
		jf.setLocationRelativeTo(null);
		jf.add(jp);
		
		jp.setLayout(null);
		
		JLabel header = new JLabel("Login");
		header.setBounds(80,1,80,25);
		jp.add(header);
		
		JLabel userLabel = new JLabel("Username: ");
		userLabel.setBounds(10,30,80,25);
		jp.add(userLabel);
		
		JTextField userText = new JTextField(20);
		userText.setBounds(100,30,165,25);
		jp.add(userText);
		
		JLabel passLabel = new JLabel("Password: ");
		passLabel.setBounds(10,60,80,25);
		jp.add(passLabel);
		
		JTextField passText = new JPasswordField();
		passText.setBounds(100,60,165,25);
		jp.add(passText);
		
		JButton buttonC = new JButton("Cancel");
		buttonC.setBounds(10,100,80,25);
		jp.add(buttonC);
		
		JButton buttonS = new JButton("Submit");
		buttonS.setBounds(100,100,80,25);
		jp.add(buttonS);
	
		jf.setVisible(true);
		
	}

}
